<!DOCTYPE html>
<html lang="en">

  <!--|| Bundle File Start ||-->
  <?php include "bundle.php" ?>
  <!--|| Bundle File End ||-->


<body>
  <!--|| Header Section Start ||-->
  <?php include "header.php" ?>
  <!--|| Header Section End ||-->


  <!--|| Main Section Start ||-->
  <main>
    <!--|| Banner Section Start ||-->
      <section class="banner-section unit-prices-banner">
        <div class="banner-container text-center ">
          <div class="row banner-content">
              <h1>Gainesville Mini Storage</h1>
              <p>2537 FM 51</p>
              <p>Gainesville, TX 76240</p>
              <p class="fw-build">(940) 400-2297</p>
              <div class="cta-btn">
                <button class="button primary-button"><i class="icon-fluent-arrow-right"></i>Start Starting Today</button>
              </div>
          </div>
        </div>
      </section>
    <!--|| Banner Section End ||-->

    <!--|| Office Access Time Section Start ||-->
    <section class="office-time-section first-padding">
      <div class="container">
        <div class="row">
          <div class="col-md-6 col-sm-6 col-12">
              <div class="office-time">
                <i class="icon-office-hours"></i>
                <h6 class="mt-3">Office Hours</h6>
                <div class="row">
                  <div class="col-md-6 col-12">
                    <p>Sunday</p>
                    <p>Monday - Friday</p>
                    <p>Saturday</p>
                  </div>
                  <div class="col-md-6 col-12">
                    <p>Closed</p>
                    <p>9:00 AM - 5:00 PM</p>
                    <p>9:00 AM - 2:00 PM</p>
                  </div>
                </div>
              </div>
          </div>
          <!-- Office Hours End -->
          
          <div class="col-md-6 col-sm-6 col-12">
              <div class="office-time access-time">
                <i class="icon-access-hours"></i>
                <h6 class="mt-3">Access Hours</h6>
                <div class="row">
                  <div class="col-md-6 col-12">
                    <p>Sunday - Saturday</p>
                    <p class="text-transparent">none</p>
                  </div>
                  <div class="col-md-6 col-12">
                    <p>Open 24 Hours</p>
                    <p class="text-transparent">none</p>
                  </div>
                </div>
                
                <div class="row">
                  <div class=" col-12">
                    <p>Remote Office - Sunday By Appointment</p>
                  </div>
                </div>
              </div>
          </div>
          <!-- Access Hours End -->

        </div>
      </div>
    </section>
    <!--|| Office Access Time Section End ||-->


    <!--|| Unit Filter Section Start ||-->
    <section class="unit-filter-section first-padding">
      <div class="container">
        <div class="row">
          <div class="col-md-2 col-12">
            <div class="search-box">
               <form>
                <input type="text" id="search" name="search" pl>
                <button type="submit" class="searchButton d-flex align-items-center">
                  <i class="icon-search"></i>
                </button>
              </form>
            </div>
            <!--Search Box End -->

            <div class="category">
              <ul>
                <li class="active"><a href="#view-all">View All</a></li>
                <li><a href="#view-all">Small</a></li>
                <li><a href="#view-all">Medium</a></li>
                <li><a href="#view-all">Large</a></li>
                <li><a href="#view-all">Vehicle</a></li>
              </ul>
            </div>
            <!--Category Item End-->
          </div>
        </div>
      </div>
    </section>
    <!--|| Unit Filter Section End ||-->

  </main>
  <!--|| Main Section End ||-->

   <!--|| Footer Section Start ||-->
  <?php include "footer.php" ?>
  <!--|| Footer Section End ||-->

</body>
</html>