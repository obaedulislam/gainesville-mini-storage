<footer class="footer-section">
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <p>Powered by: <span class="fw-bold">Redlime Solutions</span></p>
            </div>
            <div class="col-md-9 ">
                <div class="footer-menu">
                    <ul >
                        <li><a href="#">&copy; Gainesville Mini Storage</a></li>
                        <li><a href="#"> Terms</a></li>
                        <li><a href="#"> Privacy</a></li>
                        <li><a href="#"> All sizes are approximate</a></li>
                        <li><a href="#"> Some restrictions may apply</a></li>
                        <li><a href="#"> Admin</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</footer>